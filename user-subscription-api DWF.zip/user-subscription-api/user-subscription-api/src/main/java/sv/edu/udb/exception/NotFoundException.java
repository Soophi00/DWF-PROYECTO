package sv.edu.udb.exception;
public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg) { super(msg); }
}
