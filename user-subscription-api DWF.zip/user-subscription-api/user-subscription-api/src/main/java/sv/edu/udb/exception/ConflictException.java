package sv.edu.udb.exception;
public class ConflictException extends RuntimeException {
    public ConflictException(String msg) { super(msg); }
}
